<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

$base = basename($_SERVER['SCRIPT_FILENAME']);

return [
    'navUpdaterTitles' => [
        'update'    => '更新 ',
    ],
    'navUpdater' => [
        [
            'id'          => 'root.readiness-check-update',
            'url'         => 'readiness-check-updater',
            'templateUrl' => "{$base}/readiness-check-updater",
            'title'       => "准备检查",
            'header'      => '第 1 步︰ 准备检查',
            'nav'         => true,
            'order'       => 2,
            'type'        => 'update'
        ],
        [
            'id'          => 'root.readiness-check-update.progress',
            'url'         => 'readiness-check-updater/progress',
            'templateUrl' => "$base/readiness-check-updater/progress",
            'title'       => '准备检查',
            'header'      => '第 1 步︰ 准备检查',
            'controller'  => 'readinessCheckController',
            'nav'         => false,
            'order'       => 3,
            'type'        => 'update'
        ],
        [
            'id'          => 'root.create-backup-update',
            'url'         => 'create-backup',
            'templateUrl' => "$base/create-backup",
            'title'       => "创建备份",
            'header'      => '第 2 步： 创建备份',
            'controller'  => 'createBackupController',
            'nav'         => true,
            'validate'    => true,
            'order'       => 4,
            'type'        => 'update'
        ],
        [
            'id'          => 'root.create-backup-update.progress',
            'url'         => 'create-backup/progress',
            'templateUrl' => "$base/complete-backup/progress",
            'title'       => "创建备份",
            'header'      => '第 2 步： 创建备份',
            'controller'  => 'completeBackupController',
            'nav'         => false,
            'order'       => 5,
            'type'        => 'update'
        ],
        [
            'id'          => 'root.start-updater-update',
            'url'         => 'start-updater',
            'templateUrl' => "$base/start-updater",
            'controller'  => 'startUpdaterController',
            'title'       => "扩展更新",
            'header'      => '第 3 步： 扩展更新',
            'nav'         => true,
            'order'       => 6,
            'type'        => 'update'
        ],
    ],
];
