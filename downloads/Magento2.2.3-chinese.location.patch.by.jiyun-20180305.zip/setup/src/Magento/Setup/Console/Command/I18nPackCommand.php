<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Setup\Console\Command;

use Magento\Setup\Module\I18n\ServiceLocator;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Command for i18n language packaging
 */
class I18nPackCommand extends Command
{
    /**#@+
     * Keys and shortcuts for input arguments and options
     */
    const INPUT_KEY_SOURCE = 'source';
    const INPUT_KEY_LOCALE = 'locale';
    const INPUT_KEY_MODE = 'mode';
    const INPUT_KEY_ALLOW_DUPLICATES = 'allow-duplicates';
    /**#@-*/

    /**
     * 'replace' mode value
     */
    const MODE_REPLACE = 'replace';

    /**
     * 'merge' mode value
     */
    const MODE_MERGE = 'merge';

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this->setName('i18n:pack')
            ->setDescription('保存语言包');
        $this->setDefinition([
            new InputArgument(
                self::INPUT_KEY_SOURCE,
                InputArgument::REQUIRED,
                '带有翻译的源字典文件的路径'
            ),
            new InputArgument(
                self::INPUT_KEY_LOCALE,
                InputArgument::REQUIRED,
                '字典的目标区域设置, 例如 "zh_Hans_CN"'
            ),
            new InputOption(
                self::INPUT_KEY_MODE,
                'm',
                InputOption::VALUE_REQUIRED,
                '字典的保存模式' . PHP_EOL . '- "replace" - 替换新语言包' . PHP_EOL .
                '- "merge" - 合并语言包, 默认为 "replace"',
                self::MODE_REPLACE
            ),
            new InputOption(
                self::INPUT_KEY_ALLOW_DUPLICATES,
                'd',
                InputOption::VALUE_NONE,
                '使用--allow-duplicateates参数可以保存翻译的重复项。' .
                ' 否则省略参数。'
            ),
        ]);
    }

    /**
     * {@inheritdoc}
     * @throws \InvalidArgumentException
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $generator = ServiceLocator::getPackGenerator();
        $mode = $input->getOption(self::INPUT_KEY_MODE);
        if ($mode !== self::MODE_MERGE && $mode !== self::MODE_REPLACE) {
            throw new \InvalidArgumentException("'mode'选项的可用值为'replace'和'merge'");
        }
        $locale = $input->getArgument(self::INPUT_KEY_LOCALE);
        $generator->generate(
            $input->getArgument(self::INPUT_KEY_SOURCE),
            $locale,
            $input->getOption(self::INPUT_KEY_MODE),
            $input->getOption(self::INPUT_KEY_ALLOW_DUPLICATES)
        );
        $output->writeln("<info>已成功保存 $locale 语言包。</info>");
    }
}
