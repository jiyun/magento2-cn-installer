<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

require_once __DIR__ . '/app/bootstrap.php';

/**
 * Update cron exit codes
 */
const UPDATE_CRON_NORMAL_EXIT = 0;
const UPDATE_CRON_EXIT_WITH_ERROR = 1;

$status = new \Magento\Update\Status();
$cronReadinessChecker = new \Magento\Update\CronReadinessCheck();
$notification = 'update-cron: 请检查 var/log/update.log 执行摘要。' . PHP_EOL;

if (!$cronReadinessChecker->runReadinessCheck()) {
    print $notification;
    exit(UPDATE_CRON_EXIT_WITH_ERROR);
}

if ($status->isUpdateInProgress()) {
    $status->add('更新已在进行中。', \Psr\Log\LogLevel::WARNING);
    print $notification;
    exit(UPDATE_CRON_EXIT_WITH_ERROR);
}

if ($status->isUpdateError()) {
    $status->add('上次更新尝试出错。');
    print $notification;
    exit(UPDATE_CRON_EXIT_WITH_ERROR);
}

$backupDirectory = BACKUP_DIR;
if (!file_exists($backupDirectory)) {
    if (!mkdir($backupDirectory)) {
        $status->add(sprintf('备份目录 "%s" 无法创建。', $backupDirectory), \Psr\Log\LogLevel::ERROR);
        print $notification;
        exit(UPDATE_CRON_EXIT_WITH_ERROR);
    }
    chmod($backupDirectory, 0770);
}

try {
    $status->setUpdateInProgress();
} catch (\RuntimeException $e) {
    $status->add($e->getMessage(), \Psr\Log\LogLevel::ERROR);
    print $notification;
    exit(UPDATE_CRON_EXIT_WITH_ERROR);
}

$jobQueue = new \Magento\Update\Queue();
$exitCode = UPDATE_CRON_NORMAL_EXIT;
try {
    while (!empty($jobQueue->peek()) &&
        strpos($jobQueue->peek()[\Magento\Update\Queue::KEY_JOB_NAME], 'setup:') === false
    ) {
        $job = $jobQueue->popQueuedJob();
        $status->add(
            sprintf('作业 "%s" 已开始', $job)
        );
        try {
            $job->execute();
            $status->add(sprintf('作业 "%s" 已成功完成', $job), \Psr\Log\LogLevel::INFO);
        } catch (\Exception $e) {
            $status->setUpdateError();
            $status->add(
                sprintf(
                    '执行作业时出错 "%s": %s', $job, $e->getMessage(),
                    \Psr\Log\LogLevel::ERROR
                )
            );
            $status->setUpdateInProgress(false);
            $exitCode = UPDATE_CRON_EXIT_WITH_ERROR;
        };
    }
} catch (\Exception $e) {
    $status->setUpdateError();
    $status->add($e->getMessage(), \Psr\Log\LogLevel::ERROR);
    $exitCode = UPDATE_CRON_EXIT_WITH_ERROR;
} finally {
    $status->setUpdateInProgress(false);
    if ($exitCode != UPDATE_CRON_NORMAL_EXIT) {
        print $notification;
    }
    exit($exitCode);
}
