<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

$base = basename($_SERVER['SCRIPT_FILENAME']);

return [
    'navUpdaterTitles' => [
        'install' => '新购买',
    ],
    'navUpdater' => [
        [
            'id'          => 'root.readiness-check-install',
            'url'         => 'readiness-check-updater',
            'templateUrl' => "{$base}/readiness-check-updater",
            'title'       => "准备检查",
            'header'      => '第 1 步︰ 准备检查',
            'nav'         => true,
            'order'       => 2,
            'type'        => 'install',
            'wrapper'     => 1
        ],
        [
            'id'          => 'root.readiness-check-install.progress',
            'url'         => 'readiness-check-updater/progress',
            'templateUrl' => "$base/readiness-check-updater/progress",
            'title'       => '准备检查',
            'header'      => '第 1 步︰ 准备检查',
            'controller'  => 'readinessCheckController',
            'nav'         => false,
            'order'       => 3,
            'type'        => 'install',
            'wrapper'     => 1
        ],
        [
            'id'          => 'root.create-backup-install',
            'url'         => 'create-backup',
            'templateUrl' => "$base/create-backup",
            'title'       => "创建备份",
            'header'      => '第 2 步︰ 创建备份',
            'controller'  => 'createBackupController',
            'nav'         => true,
            'validate'    => true,
            'order'       => 4,
            'type'        => 'install',
            'wrapper'     => 1
        ],
        [
            'id'          => 'root.create-backup-install.progress',
            'url'         => 'create-backup/progress',
            'templateUrl' => "$base/complete-backup/progress",
            'title'       => "创建备份",
            'header'      => '第 2 步︰ 创建备份',
            'controller'  => 'completeBackupController',
            'nav'         => false,
            'order'       => 5,
            'type'        => 'install',
            'wrapper'     => 1
        ],
        [
            'id'          => 'root.start-updater-install',
            'url'         => 'start-updater',
            'templateUrl' => "$base/start-updater",
            'controller'  => 'startUpdaterController',
            'title'       => "组件安装",
            'header'      => '第 3 步︰ 安装',
            'nav'         => true,
            'order'       => 6,
            'type'        => 'install',
            'wrapper'     => 1
        ],
    ],
];
