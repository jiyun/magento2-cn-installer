<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

$base = basename($_SERVER['SCRIPT_FILENAME']);

return [
    'navUpdaterTitles' => [
        'enable'    => '启用 ',
    ],
    'navUpdater' => [
        [
            'id'          => 'root.readiness-check-enable',
            'url'         => 'readiness-check-enable',
            'templateUrl' => "{$base}/readiness-check-updater",
            'title'       => "准备检查",
            'header'      => '第 1 步︰ 准备检查',
            'nav'         => true,
            'order'       => 2,
            'type'        => 'enable'
        ],
        [
            'id'          => 'root.readiness-check-enable.progress',
            'url'         => 'readiness-check-enable/progress',
            'templateUrl' => "$base/readiness-check-updater/progress",
            'title'       => '准备检查',
            'header'      => '第 1 步︰ 准备检查',
            'controller'  => 'readinessCheckController',
            'nav'         => false,
            'order'       => 3,
            'type'        => 'enable'
        ],
        [
            'id'          => 'root.create-backup-enable',
            'url'         => 'create-backup',
            'templateUrl' => "$base/create-backup",
            'title'       => "创建备份",
            'header'      => '第 2 步︰ 创建备份',
            'controller'  => 'createBackupController',
            'nav'         => true,
            'validate'    => true,
            'order'       => 4,
            'type'        => 'enable'
        ],
        [
            'id'          => 'root.create-backup-enable.progress',
            'url'         => 'create-backup/progress',
            'templateUrl' => "$base/complete-backup/progress",
            'title'       => "创建备份",
            'header'      => '第 2 步︰ 创建备份',
            'controller'  => 'completeBackupController',
            'nav'         => false,
            'order'       => 5,
            'type'        => 'enable'
        ],
        [
            'id'          => 'root.start-updater-enable',
            'url'         => 'enable',
            'templateUrl' => "$base/start-updater",
            'title'       => "启用模块",
            'controller'  => 'startUpdaterController',
            'header'      => '第 3 步︰ 启用模块',
            'nav'         => true,
            'order'       => 6,
            'type'        => 'enable'
        ],
        [
            'id'          => 'root.enable-success',
            'url'         => 'enable-success',
            'templateUrl' => "$base/updater-success",
            'controller'  => 'updaterSuccessController',
            'order'       => 7,
            'main'        => true,
            'noMenu'      => true
        ],
    ],
];
