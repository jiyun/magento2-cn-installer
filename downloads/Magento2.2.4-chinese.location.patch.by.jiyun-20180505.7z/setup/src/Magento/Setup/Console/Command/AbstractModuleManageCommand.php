<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Setup\Console\Command;

use Magento\Framework\Code\GeneratedFiles;
use Magento\Setup\Model\ObjectManagerProvider;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputOption;
use Magento\Framework\App\DeploymentConfig;
use Magento\Framework\Module\Status;

abstract class AbstractModuleManageCommand extends AbstractModuleCommand
{
    /**
     * Names of input arguments or options
     */
    const INPUT_KEY_ALL = 'all';
    const INPUT_KEY_FORCE = 'force';

    /**
     * @var GeneratedFiles
     */
    protected $generatedFiles;

    /**
     * @var DeploymentConfig
     */
    protected $deploymentConfig;

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this->addOption(
            self::INPUT_KEY_FORCE,
            'f',
            InputOption::VALUE_NONE,
            '绕过依赖关系检查'
        );
        $this->addOption(
            self::INPUT_KEY_ALL,
            null,
            InputOption::VALUE_NONE,
            ($this->isEnable() ? '启用' : '关闭') . ' 全部模块'
        );

        parent::configure();
    }

    /**
     * {@inheritdoc}
     */
    protected function isModuleRequired()
    {
        return false;
    }

    /**
     * {@inheritdoc}
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $isEnable = $this->isEnable();
        if ($input->getOption(self::INPUT_KEY_ALL)) {
            /** @var \Magento\Framework\Module\FullModuleList $fullModulesList */
            $fullModulesList = $this->objectManager->get(\Magento\Framework\Module\FullModuleList::class);
            $modules = $fullModulesList->getNames();
        } else {
            $modules = $input->getArgument(self::INPUT_KEY_MODULES);
        }
        $messages = $this->validate($modules);
        if (!empty($messages)) {
            $output->writeln(implode(PHP_EOL, $messages));
            // we must have an exit code higher than zero to indicate something was wrong
            return \Magento\Framework\Console\Cli::RETURN_FAILURE;
        }
        try {
            $modulesToChange = $this->getStatus()->getModulesToChange($isEnable, $modules);
        } catch (\LogicException $e) {
            $output->writeln('<error>' . $e->getMessage() . '</error>');
            // we must have an exit code higher than zero to indicate something was wrong
            return \Magento\Framework\Console\Cli::RETURN_FAILURE;
        }
        if (!empty($modulesToChange)) {
            $force = $input->getOption(self::INPUT_KEY_FORCE);
            if (!$force) {
                $constraints = $this->getStatus()->checkConstraints($isEnable, $modulesToChange);
                if ($constraints) {
                    $output->writeln(
                        "<error>由于以下限制，无法更改模块的状态：</error>"
                    );
                    $output->writeln('<error>' . implode("</error>\n<error>", $constraints) . '</error>');
                    // we must have an exit code higher than zero to indicate something was wrong
                    return \Magento\Framework\Console\Cli::RETURN_FAILURE;
                }
            }
            $this->setIsEnabled($isEnable, $modulesToChange, $output);
            $this->cleanup($input, $output);
            $this->getGeneratedFiles()->requestRegeneration();
            if ($force) {
                $output->writeln(
                    '<error>警报：您使用了--force选项,模块可能无法正常工作。</error>'
                );
            }
        } else {
            $output->writeln('<info>没有模块改变。</info>');
        }
    }

    /**
     * Enable/disable modules
     *
     * @param bool $isEnable
     * @param string[] $modulesToChange
     * @param OutputInterface $output
     * @return void
     */
    private function setIsEnabled($isEnable, $modulesToChange, $output)
    {
        $this->getStatus()->setIsEnabled($isEnable, $modulesToChange);
        if ($isEnable) {
            $output->writeln('<info>以下模块已启用：</info>');
            $output->writeln('<info>- ' . implode("\n- ", $modulesToChange) . '</info>');
            $output->writeln('');
            if ($this->getDeploymentConfig()->isAvailable()) {
                $output->writeln(
                    '<info>为确保启用的模块已正确注册，'
                    . " 运行 'setup:upgrade'.</info>"
                );
            }
        } else {
            $output->writeln('<info>以下模块已关闭：</info>');
            $output->writeln('<info>- ' . implode("\n- ", $modulesToChange) . '</info>');
            $output->writeln('');
        }
    }

    /**
     * Get module status
     *
     * @return Status
     */
    private function getStatus()
    {
        return $this->objectManager->get(Status::class);
    }

    /**
     * Validate list of modules and return error messages
     *
     * @param string[] $modules
     * @return string[]
     */
    protected function validate(array $modules)
    {
        $messages = [];
        if (empty($modules)) {
            $messages[] = '<error>没有指定模块。 用空格分隔模块列表或使用--all选项</error>';
        }
        return $messages;
    }

    /**
     * Is it "enable" or "disable" command
     *
     * @return bool
     */
    abstract protected function isEnable();

    /**
     * Get deployment config
     *
     * @return DeploymentConfig
     * @deprecated 2.0.6
     */
    private function getDeploymentConfig()
    {
        if (!($this->deploymentConfig instanceof DeploymentConfig)) {
            return $this->objectManager->get(DeploymentConfig::class);
        }
        return $this->deploymentConfig;
    }

    /**
     * Get deployment config
     *
     * @return GeneratedFiles
     * @deprecated 2.1.0
     */
    private function getGeneratedFiles()
    {
        if (!($this->generatedFiles instanceof GeneratedFiles)) {
            return $this->objectManager->get(GeneratedFiles::class);
        }
        return $this->generatedFiles;
    }
}
