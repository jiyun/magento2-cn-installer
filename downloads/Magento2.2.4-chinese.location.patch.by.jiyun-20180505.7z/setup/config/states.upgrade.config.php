<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

$base = basename($_SERVER['SCRIPT_FILENAME']);

return [
    'navUpdaterTitles' => [
        'upgrade'    => '系统升级',
    ],
    'navUpdater' => [
        [
            'id'          => 'root.select-version',
            'url'         => 'select-version',
            'templateUrl' => "$base/select-version",
            'title'       => '系统升级',
            'controller'  => 'selectVersionController',
            'header'      => '第 1 步： 选择版本',
            'order'       => 2,
            'nav'         => true,
            'type'        => 'upgrade'
        ],
        [
            'id'          => 'root.readiness-check-upgrade',
            'url'         => 'readiness-check-updater',
            'templateUrl' => "$base/readiness-check-updater",
            'title'       => "准备检查",
            'header'      => '第 2 步： 准备检查',
            'order'       => 3,
            'nav'         => true,
            'type'        => 'upgrade'
        ],
        [
            'id'          => 'root.readiness-check-upgrade.progress',
            'url'         => 'readiness-check-updater/progress',
            'templateUrl' => "$base/readiness-check-updater/progress",
            'title'       => '准备检查',
            'header'      => '第 2 步： 准备检查',
            'controller'  => 'readinessCheckController',
            'nav'         => false,
            'order'       => 4,
            'type'        => 'upgrade'
        ],
        [
            'id'          => 'root.create-backup-upgrade',
            'url'         => 'create-backup',
            'templateUrl' => "$base/create-backup",
            'title'       => '创建备份',
            'controller'  => 'createBackupController',
            'header'      => '第 3 步： 创建备份',
            'order'       => 5,
            'nav'         => true,
            'type'        => 'upgrade'
        ],
        [
            'id'          => 'root.create-backup-upgrade.progress',
            'url'         => 'create-backup/progress',
            'templateUrl' => "$base/complete-backup/progress",
            'title'       => "创建备份",
            'header'      => '第 3 步： 创建备份',
            'controller'  => 'completeBackupController',
            'nav'         => false,
            'order'       => 6,
            'type'        => 'upgrade'
        ],
        [
            'id'          => 'root.start-updater-upgrade',
            'url'         => 'start-updater',
            'templateUrl' => "$base/start-updater",
            'title'       => "系统升级",
            'controller'  => 'startUpdaterController',
            'header'      => '第 4 步： 系统升级',
            'order'       => 7,
            'nav'         => true,
            'type'        => 'upgrade'
        ],
        [
            'id'          => 'root.updater-success',
            'url'         => 'updater-success',
            'templateUrl' => "$base/updater-success",
            'controller'  => 'updaterSuccessController',
            'order'       => 8,
            'noMenu'      => true
        ],
        [
            'id'          => 'root.system-config',
            'url'         => 'system-config',
            'templateUrl' => "$base/system-config",
            'title'       => '系统配置',
            'controller'  => 'systemConfigController',
            'default'     => false,
            'nav-bar'     => false,
            'noMenu'      => true,
            'order'       => -1,
        ]
    ],
];
