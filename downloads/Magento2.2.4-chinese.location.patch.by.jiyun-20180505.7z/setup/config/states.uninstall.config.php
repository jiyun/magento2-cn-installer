<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

$base = basename($_SERVER['SCRIPT_FILENAME']);

return [
    'navUpdaterTitles' => [
        'uninstall'    => '卸载 ',
    ],
    'navUpdater' => [
        [
            'id'          => 'root.readiness-check-uninstall',
            'url'         => 'readiness-check-uninstall',
            'templateUrl' => "{$base}/readiness-check-updater",
            'title'       => "准备检查",
            'header'      => '第 1 步︰ 准备检查',
            'nav'         => true,
            'order'       => 2,
            'type'        => 'uninstall'
        ],
        [
            'id'          => 'root.readiness-check-uninstall.progress',
            'url'         => 'readiness-check-uninstall/progress',
            'templateUrl' => "$base/readiness-check-updater/progress",
            'title'       => '准备检查',
            'header'      => '第 1 步︰ 准备检查',
            'controller'  => 'readinessCheckController',
            'nav'         => false,
            'order'       => 3,
            'type'        => 'uninstall'
        ],
        [
            'id'          => 'root.create-backup-uninstall',
            'url'         => 'create-backup',
            'templateUrl' => "$base/create-backup",
            'title'       => "创建备份",
            'header'      => '第 2 步： 创建备份',
            'controller'  => 'createBackupController',
            'nav'         => true,
            'validate'    => true,
            'order'       => 4,
            'type'        => 'uninstall'
        ],
        [
            'id'          => 'root.create-backup-uninstall.progress',
            'url'         => 'create-backup/progress',
            'templateUrl' => "$base/complete-backup/progress",
            'title'       => "创建备份",
            'header'      => '第 2 步： 创建备份',
            'controller'  => 'completeBackupController',
            'nav'         => false,
            'order'       => 5,
            'type'        => 'uninstall'
        ],
        [
            'id'          => 'root.data-option',
            'url'         => 'data-option',
            'templateUrl' => "$base/data-option",
            'title'       => "删除 或 \n 保留数据",
            'controller'  => 'dataOptionController',
            'header'      => '第 3 步： 删除或保留数据',
            'nav'         => true,
            'order'       => 6,
            'type'        => 'uninstall'
        ],
        [
            'id'          => 'root.start-updater-uninstall',
            'url'         => 'uninstall',
            'templateUrl' => "$base/start-updater",
            'title'       => "卸载",
            'controller'  => 'startUpdaterController',
            'header'      => '第 4 步： 卸载',
            'nav'         => true,
            'order'       => 7,
            'type'        => 'uninstall'
        ],
        [
            'id'          => 'root.uninstall-success',
            'url'         => 'uninstall-success',
            'templateUrl' => "$base/updater-success",
            'controller'  => 'updaterSuccessController',
            'order'       => 8,
            'main'        => true,
            'noMenu'      => true
        ],
    ],
];
