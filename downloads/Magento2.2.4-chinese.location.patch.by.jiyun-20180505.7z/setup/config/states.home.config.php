<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

$base = basename($_SERVER['SCRIPT_FILENAME']);

return [
    'navUpdater' => [
        [
            'id'          => 'root',
            'step'        => 0,
            'views'       => ['root' => []],
        ],
        [
            'id'          => 'root.home',
            'url'         => 'home',
            'title'       => '安裝向导',
            'templateUrl' => "$base/home",
            'header'      => '主页',
            'nav'         => false,
            'default'     => true,
            'noMenu'      => true,
            'order'       => -1,
        ],
        [
            'id'          => 'root.module',
            'url'         => 'module-grid',
            'templateUrl' => "$base/module-grid",
            'title'       => '模块管理',
            'controller'  => 'moduleGridController',
            'nav'         => false,
            'noMenu'      => true,
            'order'       => 1,
            'type'        => 'module'
        ],
        [
            'id'          => 'root.extension-auth',
            'url'         => 'marketplace-credentials',
            'templateUrl' => "$base/marketplace-credentials",
            'title'       => '扩展管理',
            'controller'  => 'MarketplaceCredentialsController',
            'order'       => 1,
            'nav'         => false,
            'noMenu'      => true,
            'type'        => 'extension'
        ],
        [
            'id'          => 'root.extension',
            'url'         => 'extension-grid',
            'templateUrl' => "$base/extension-grid",
            'title'       => '扩展管理',
            'controller'  => 'extensionGridController',
            'order'       => 2,
            'nav'         => false,
            'noMenu'      => true,
            'type'        => 'extension'
        ],
        [
            'id'          => 'root.install',
            'url'         => 'install-extension-grid',
            'templateUrl' => "$base/install-extension-grid",
            'title'       => "扩展网格",
            'controller'  => 'installExtensionGridController',
            'nav'         => false,
            'noMenu'      => true,
            'order'       => 1,
            'type'        => 'install',
            'wrapper'     => 1,
            'header'      => '准备安装'
        ],
        [
            'id'          => 'root.update',
            'url'         => 'update-extension-grid',
            'templateUrl' => "$base/update-extension-grid",
            'title'       => "扩展管理",
            'controller'  => 'updateExtensionGridController',
            'nav'         => false,
            'noMenu'      => true,
            'order'       => 1,
            'type'        => 'update',
            'wrapper'     => 1,
            'header'      => '新建更新'
        ],
        [
            'id'          => 'root.upgrade',
            'url'         => 'marketplace-credentials',
            'templateUrl' => "$base/marketplace-credentials",
            'title'       => '系统升级',
            'controller'  => 'MarketplaceCredentialsController',
            'order'       => 1,
            'nav'         => false,
            'noMenu'      => true,
            'type'        => 'upgrade'
        ],
    ],
];
