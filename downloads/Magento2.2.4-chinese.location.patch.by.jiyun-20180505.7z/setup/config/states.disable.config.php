<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

$base = basename($_SERVER['SCRIPT_FILENAME']);

return [
    'navUpdaterTitles' => [
        'disable'    => '关闭 ',
    ],
    'navUpdater' => [
        [
            'id'          => 'root.readiness-check-disable',
            'url'         => 'readiness-check-disable',
            'templateUrl' => "{$base}/readiness-check-updater",
            'title'       => "准备检查",
            'header'      => '第 1 步︰ 准备检查',
            'nav'         => true,
            'order'       => 2,
            'type'        => 'disable'
        ],
        [
            'id'          => 'root.readiness-check-disable.progress',
            'url'         => 'readiness-check-disable/progress',
            'templateUrl' => "$base/readiness-check-updater/progress",
            'title'       => '准备检查',
            'header'      => '第 1 步︰ 准备检查',
            'controller'  => 'readinessCheckController',
            'nav'         => false,
            'order'       => 3,
            'type'        => 'disable'
        ],
        [
            'id'          => 'root.create-backup-disable',
            'url'         => 'create-backup',
            'templateUrl' => "$base/create-backup",
            'title'       => "创建备份",
            'header'      => '第 2 步： 创建备份',
            'controller'  => 'createBackupController',
            'nav'         => true,
            'validate'    => true,
            'order'       => 4,
            'type'        => 'disable'
        ],
        [
            'id'          => 'root.create-backup-disable.progress',
            'url'         => 'create-backup/progress',
            'templateUrl' => "$base/complete-backup/progress",
            'title'       => "创建备份",
            'header'      => '第 2 步： 创建备份',
            'controller'  => 'completeBackupController',
            'nav'         => false,
            'order'       => 5,
            'type'        => 'disable'
        ],
        [
            'id'          => 'root.start-updater-disable',
            'url'         => 'disable',
            'templateUrl' => "$base/start-updater",
            'title'       => "关闭",
            'controller'  => 'startUpdaterController',
            'header'      => '第 3 步︰ 关闭',
            'nav'         => true,
            'order'       => 6,
            'type'        => 'disable'
        ],
        [
            'id'          => 'root.disable-success',
            'url'         => 'disable-success',
            'templateUrl' => "$base/updater-success",
            'controller'  => 'updaterSuccessController',
            'order'       => 7,
            'main'        => true,
            'noMenu'      => true
        ],
    ],
];
